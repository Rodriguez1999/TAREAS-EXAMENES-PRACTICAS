function verHistoria(index){
    document.getElementById('modal-historias').innerHTML =``;

    for(let i=0; i<historias[index].historia.length; i++){
        document.getElementById('modal-historias').innerHTML += `
        <div class="historia">
            <div class="historia-image-post" style="background-image: url(${historias[index].historia[i].imagen})">
                <div class="historia-titulo">${historias[index].historia[i].titulo}</div>
            </div>
        </div>
        `;

    }

    $('#ver-historia').modal('show');
}

function comentar(codigoPost){
    axios({
        method: 'PUT',
        url: '../backend/api/posts.php',
        responseType: 'json',
        data:{
            codigoUsuario: document.getElementById('usuario-actual').value, 
            codigoPost: codigoPost,
            contenidoComentario: document.getElementById(`comentario-post-${codigoPost}`).value,
        }
        }).then(res=>{
            respuesta = res.data;
            console.log(res);
            verPost();
    }).catch(error=>{
        console.error(error);
    });
}

function usuarios(){
    axios({
        method: 'GET',
        url: '../backend/api/usuario.php',
        responseType: 'json'
        }).then(res=>{
            respuesta = res.data;
            document.getElementById('usuario-actual').innerHTML = `<option value=null>--Seleccione un Usuario</option>`;
            for(let i=0; i<respuesta.length; i++){
                document.getElementById('usuario-actual').innerHTML += `
                    <option value=${respuesta[i].codigoUsuario}>${respuesta[i].nombre}</option>
                `;

            }
    }).catch(error=>{
        console.error(error);
    });
}

function verPost(){
    axios({
        method: 'GET',
        url: '../backend/api/posts.php'+`?id=${document.getElementById('usuario-actual').value}`,
        responseType: 'json'
        }).then(res=>{
            respuesta = res.data;
            document.getElementById('posts').innerHTML = ``;
            obtenerHistorias();
            for(let i=0; i<respuesta.length; i++){
                document.getElementById('posts').innerHTML += `
                    <div class="col-lg-12">
                    <div class="card mb-4 shadow-sm">
                    <div class="card-header">
                        <img class="img-fluid img-thumbnail rounded-circle" src="${respuesta[i].imagenUsuario}">    
                        <span>${respuesta[i].nombre}</span>
                    </div>
                    <div class="card-body px-0 py-0">
                        <div class="image-post" style="background-image: url(${respuesta[i].imagen});">
    
                        </div>
                        <div class="px-3 py-3 post">
                        <span class="pointer" onclick="like(1);"><i class="far fa-heart"></i></span>&nbsp;${respuesta[i].cantidadLikes} Likes<br>
                        <span class="post-user">${respuesta[i].nombre}</span>
                        <span class="post-content">${respuesta[i].contenidoPost}</span>
                        <hr>
                        <b>Comments</b><br>
                            ${comentariosPost(respuesta[i].comentarios)}
                        <hr>
                        <div class="px-0">
                            <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Comment" id="comentario-post-${respuesta[i].codigoPost}">
                            <div class="input-group-append">
                                <button type="button" onclick="comentar(${respuesta[i].codigoPost});" class="btn btn-outline-danger"><i class="far fa-paper-plane"></i></button>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                `;

            }
            
    }).catch(error=>{
        console.error(error);
    });
}

function comentariosPost(comentarios){

    let contenido=``;
    for(let i=0; i<comentarios.length; i++){
        contenido+=`
        <div>
            <span class="post-user">${comentarios[i].usuario}</span>
            <span class="post-content">${comentarios[i].comentario}</span>
        </div>
        `;
    }
    return contenido;
}

function obtenerHistorias(){
    axios({
        method: 'GET',
        url: '../backend/api/historia.php'+`?id=${document.getElementById('usuario-actual').value}`,
        responseType: 'json'
        }).then(res=>{
            historias = res.data;
            console.log(historias);
            document.getElementById('historias-lista').innerHTML = `
            <div class="card-header">
                  Stories
                </div>`;
            for(let i=0; i<historias.length; i++){
                document.getElementById('historias-lista').innerHTML += `
                <div class="px-1 py-2 story-card pointer" onclick="verHistoria(${i});">
                    <div class="fl">
                    <img class="img-fluid img-thumbnail rounded-circle img-thumbnail-historia" src="${historias[i].imagenUsuario}">
                    </div>  
                    <div class="py-1 px-1 fl">
                    <small><b>${historias[i].usuario}(${historias[i].historia.length})</b></small><br>
                    <small class="muted">12/12/2012</small>
                    </div>
                </div>
                `;

            }
            
    }).catch(error=>{
        console.error(error);
    });
}

function nuevoPost(){
    axios({
        method: 'POST',
        url: '../backend/api/posts.php',
        responseType: 'json',
        data: {
            codigoUsuario: document.getElementById('usuario-actual').value,
            contenidoPost: document.getElementById('contenido-post').value,
            imagen: document.getElementById('url-imagen').value
        }
    }).then(res=>{
        document.getElementById('contenido-post').value == null;
        document.getElementById('url-imagen').value == null;
            
    }).catch(error=>{
        console.error(error);
    });
}