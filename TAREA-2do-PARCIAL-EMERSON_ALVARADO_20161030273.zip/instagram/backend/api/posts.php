<?php
//localhost:/..../api/usuario.php
    //Recicbir peticiones del usuario
   // echo "Metodo HTTP: ".$_SERVER['REQUEST_METHOD'];
    header("Content-type: application/json");
    include_once("../class/class-post.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST'://guardar
            $_POST =json_decode(file_get_contents('php://input'), true);
            $post = new Post($_POST["codigoUsuario"],
                            $_POST["contenidoPost"],
                            $_POST["imagen"]);

            $post -> guardarPost();
        break;
        case 'GET':
            if(isset($_GET['id'])){
                Post::obtenerPosts($_GET['id']);
            }else{
               // Post::obtenerUsuarios();
            }
        break;
        case 'PUT'://actualizar
            $_PUT =json_decode(file_get_contents('php://input'), true);
            $post = new Post($_PUT["codigoUsuario"],
                            $_PUT["codigoPost"],
                            $_PUT["contenidoComentario"]);
            $post -> guardarComentario();
        break;
        case 'DELETE'://Eliminar
        break;
    }
?>