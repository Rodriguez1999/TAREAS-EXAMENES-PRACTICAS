<?php
//localhost:/..../api/usuario.php
    //Recicbir peticiones del usuario
   // echo "Metodo HTTP: ".$_SERVER['REQUEST_METHOD'];
    header("Content-type: application/json");
    include_once("../class/class-usuario.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST'://guardar
        break;
        case 'GET':
            if(isset($_GET['id'])){
                Usuario::obtenerUsuario($_GET['id']);
            }else{
                Usuario::obtenerUsuarios();
            }
        break;
        case 'PUT'://actualizar
        break;
        case 'DELETE'://Eliminar
        break;
    }
?>