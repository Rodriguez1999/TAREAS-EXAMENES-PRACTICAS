<?php
    header("Content-type: application/json");
    include_once("../class/class-historia.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST'://guardar
        break;
        case 'GET':
            if(isset($_GET['id'])){
                Historias::obtenerHistoria($_GET['id']);
            }else{
               // Post::obtenerUsuarios();
            }
        break;
        case 'PUT'://actualizar
        break;
        case 'DELETE'://Eliminar
        break;
    }
?>