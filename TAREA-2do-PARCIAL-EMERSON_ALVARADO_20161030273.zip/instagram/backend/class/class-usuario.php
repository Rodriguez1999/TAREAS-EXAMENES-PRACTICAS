<?php 

    class Usuario{
        private $codigoUsuario;
        private $nombre;
        private $correo;
        private $contrasena;
        private $imagen;
        private $siguiendo;

        public function __construct($codigoUsuario, $nombre, $correo, $contrasena, $imagen, $siguiendo)
        {
            $this->codigoUsuario = $codigoUsuario;
            $this->nombre = $nombre;
            $this->correo = $correo;
            $this->contrasena = $contrasena;
            $this->imagen = $imagen;
            $this->siguiendo = $siguiendo;
        }

        public static function obtenerUsuarios(){
            $contenidoArchivo = file_get_contents('../data/usuarios.json');
            echo $contenidoArchivo;

        }
        public function obtenerUsuario($index){

        }

        public function getCodigoUsuario()
        {
                return $this->codigoUsuario;
        }

        public function setCodigoUsuario($codigoUsuario)
        {
                $this->codigoUsuario = $codigoUsuario;

                return $this;
        }
        
        public function getNombre()
        {
                return $this->nombre;
        }

        public function setNombre($nombre)
        {
                $this->nombre = $nombre;

                return $this;
        }

        public function getCorreo()
        {
                return $this->correo;
        }

        public function setCorreo($correo)
        {
                $this->correo = $correo;

                return $this;
        }

        public function getContrasena()
        {
                return $this->contrasena;
        }

        public function setContrasena($contrasena)
        {
                $this->contrasena = $contrasena;

                return $this;
        }

        public function getImagen()
        {
                return $this->imagen;
        }

        public function setImagen($imagen)
        {
                $this->imagen = $imagen;

                return $this;
        }

        public function getSiguiendo()
        {
                return $this->siguiendo;
        }

        public function setSiguiendo($siguiendo)
        {
                $this->siguiendo = $siguiendo;

                return $this;
        }
    }

?>