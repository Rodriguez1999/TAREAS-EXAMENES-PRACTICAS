<?php

    class Post{
        private $codigoPost;
        private $codigoUsuario;
        private $contenidoPost;
        private $imagen;
        private $cantidadLikes;

        public function __construct( $codigoUsuario, $contenidoPost, $imagen)
        {
        $this -> codigoUsuario = $codigoUsuario;
        $this -> contenidoPost = $contenidoPost;
        $this -> imagen = $imagen;
        }

        public function guardarPost(){
                $contenidoArchivo = file_get_contents('../data/posts.json');
                $posts = json_decode($contenidoArchivo, true);

                $this -> codigoPost = $posts[sizeof($posts)-1]["codigoPost"]+1;

                $posts[]= array(
                        "codigoPost"=> $this -> codigoPost,
                        "codigoUsuario"=> $this -> codigoUsuario,
                        "contenidoPost"=> $this -> contenidoPost,
                        "imagen"=> $this -> imagen,
                        "cantidadLikes"=> 0
                );

                $archivo = fopen("../data/posts.json", "w");
                fwrite($archivo, json_encode($posts));
                fclose($archivo);
        }

        public static function obtenerPosts($index){
            $contenidoArchivo = file_get_contents('../data/usuarios.json');
            $usuarios = json_decode($contenidoArchivo, true);
            $usuario = null;

            for($i=0; $i<sizeof($usuarios); $i++){
                if($usuarios[$i]["codigoUsuario"] == $index){
                    $usuario = $usuarios[$i];
                break;
                }
            }

            $contenidoArchivoComentarios = file_get_contents('../data/comentarios.json');
            $comentarios = json_decode($contenidoArchivoComentarios, true);

            $contenidoArchivoPosts = file_get_contents('../data/posts.json');
            $posts = json_decode($contenidoArchivoPosts, true);
            $resultadoPost = array();
            $comen = array();

            for($i=0; $i < sizeof($usuario["siguiendo"]); $i++){
                    for($j=0; $j < sizeof($posts); $j++){
                            $comen = array();
                            if($usuario["siguiendo"][$i] == $posts[$j]["codigoUsuario"]){
                                for($k = 0; $k <sizeof($comentarios); $k++){
                                        if($posts[$j]["codigoPost"] == $comentarios[$k]["codigoPost"]){
                                                $comen[] = array(
                                                        "usuario"=> $comentarios[$k]["usuario"],
                                                        "comentario"=> $comentarios[$k]["comentario"]
                                                );
                                        }       
                                }
                                for($l=0; $l<sizeof($usuarios); $l++){
                                        if($posts[$j]["codigoUsuario"] == $usuarios[$l]["codigoUsuario"]){
                                                $nombre= $usuarios[$l]["nombre"];
                                                $imgUsuario = $usuarios[$l]["imagen"];
                                        }
                                }

                                $resultadoPost[]= array(
                                        "nombre"=> $nombre,
                                        "codigoPost" => $posts[$j]["codigoPost"],
                                        "imagenUsuario" => $imgUsuario,
                                        "contenidoPost"=> $posts[$j]["contenidoPost"],
                                        "imagen"=> $posts[$j]["imagen"],
                                        "cantidadLikes"=> $posts[$j]["cantidadLikes"],
                                        "comentarios" => $comen
                                );
                            }
                    }
                }
                echo json_encode($resultadoPost);

        }

        public function guardarComentario(){
                $contenidoArchivo = file_get_contents('../data/comentarios.json');
                $comentarios = json_decode($contenidoArchivo, true);

                $contenidoArchivo = file_get_contents('../data/usuarios.json');
                $usuarios = json_decode($contenidoArchivo, true);

                for($i=0; $i< sizeof($usuarios); $i++){
                        if($this->codigoUsuario == $usuarios[$i]["codigoUsuario"]){
                                $nombre = $usuarios[$i]["nombre"];
                        }
                }

                $codigoComentario = $comentarios[sizeof($comentarios)-1]["codigoComentario"]+1;

                $comentarios[]= array(
                        "codigoComentario"=> $codigoComentario,
                        "codigoPost"=> $this->contenidoPost,
                        "usuario"=> $nombre,
                        "comentario"=> $this->imagen
                );

                $archivo = fopen("../data/comentarios.json", "w");
                fwrite($archivo, json_encode($comentarios));
                fclose($archivo);
        }

        public function getCodigoPost()
        {
                return $this->codigoPost;
        }

        public function setCodigoPost($codigoPost)
        {
                $this->codigoPost = $codigoPost;

                return $this;
        }
 
        public function getCodigoUsuario()
        {
                return $this->codigoUsuario;
        }

        public function setCodigoUsuario($codigoUsuario)
        {
                $this->codigoUsuario = $codigoUsuario;

                return $this;
        }

        public function getContenidoPost()
        {
                return $this->contenidoPost;
        }

        public function setContenidoPost($contenidoPost)
        {
                $this->contenidoPost = $contenidoPost;

                return $this;
        }

        public function getImagen()
        {
                return $this->imagen;
        }

        public function setImagen($imagen)
        {
                $this->imagen = $imagen;

                return $this;
        }

        public function getCantidadLikes()
        {
                return $this->cantidadLikes;
        }

        public function setCantidadLikes($cantidadLikes)
        {
                $this->cantidadLikes = $cantidadLikes;

                return $this;
        }
    }
?>