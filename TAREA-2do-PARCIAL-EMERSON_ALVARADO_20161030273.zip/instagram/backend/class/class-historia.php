<?php

    class Historias{
        private $codigoHistoria;
        private $usuario;
        private $imagenUsuario;
        private $titulo;
        private $imagen;

        public function __construct(
            $codigoHistoria,
            $usuario,
            $imagenUsuario,
            $titulo,
            $imagen
        )
        {
            $this-> codigoHistoria = $codigoHistoria;
            $this-> usuario = $usuario;
            $this-> imagenUsuario = $imagenUsuario;
            $this-> titulo = $titulo;
            $this-> imagen = $imagen;
        }

        public static function obtenerHistoria($index){
            $contenidoArchivo = file_get_contents('../data/usuarios.json');
            $usuarios = json_decode($contenidoArchivo, true);

            $contenidoArchivoHistoria = file_get_contents('../data/historias.json');
            $historias = json_decode($contenidoArchivoHistoria, true);

            for($i=0; $i<sizeof($usuarios); $i++){
                if($index == $usuarios[$i]["codigoUsuario"]){
                    $usuario = $usuarios[$i];
                }
            }

            $arregloHistorias = array();

            for($i=0; $i<sizeof($usuario["siguiendo"]); $i++){
                for($j=0; $j<sizeof($usuarios); $j++){
                    if($usuario["siguiendo"][$i] == $usuarios[$j]["codigoUsuario"]){
                        for($k =0; $k< sizeof($historias); $k++){
                            if($usuarios[$j]["nombre"] == $historias[$k]["usuario"]){
                                $arregloHistorias[] = $historias[$k]; 
                            }
                        }
                    }

                }
            }

            echo json_encode($arregloHistorias);

        }
 
        public function getCodigoHistoria()
        {
                return $this->codigoHistoria;
        }
 
        public function setCodigoHistoria($codigoHistoria)
        {
                $this->codigoHistoria = $codigoHistoria;

                return $this;
        }

        public function getUsuario()
        {
                return $this->usuario;
        }

        public function setUsuario($usuario)
        {
                $this->usuario = $usuario;

                return $this;
        }

        public function getImagenUsuario()
        {
                return $this->imagenUsuario;
        }
 
        public function setImagenUsuario($imagenUsuario)
        {
                $this->imagenUsuario = $imagenUsuario;

                return $this;
        }

        public function getTitulo()
        {
                return $this->titulo;
        }

        public function setTitulo($titulo)
        {
                $this->titulo = $titulo;

                return $this;
        }

        public function getImagen()
        {
                return $this->imagen;
        }
 
        public function setImagen($imagen)
        {
                $this->imagen = $imagen;

                return $this;
        }
    }
?>