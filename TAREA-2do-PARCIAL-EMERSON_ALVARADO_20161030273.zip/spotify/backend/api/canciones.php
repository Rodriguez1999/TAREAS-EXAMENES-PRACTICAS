<?php
    header("Content-type: application/json");
    include_once("../class/class-canciones.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST':
        break;
        case 'GET':
        break;
        case 'PUT':
            $_PUT =json_decode(file_get_contents('php://input'), true); 
            $datos = new Canciones($_PUT['artista'], $_PUT['album'], $_PUT['cancion'], $_PUT['playlist']);
            $datos -> agregarCancion($_PUT['usuario'], $_PUT['artista'], $_PUT['album'], $_PUT['cancion'], $_PUT['playlist']);
            echo json_decode(file_get_contents('php://input'), true); 
        break;
        case 'DELETE':
        break;
    }
?>