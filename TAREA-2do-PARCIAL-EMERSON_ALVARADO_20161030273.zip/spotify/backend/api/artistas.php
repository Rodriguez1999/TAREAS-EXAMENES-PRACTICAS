<?php
//localhost:/..../api/usuario.php
    //Recicbir peticiones del usuario
   // echo "Metodo HTTP: ".$_SERVER['REQUEST_METHOD'];
    header("Content-type: application/json");
    include_once("../class/class-artistas.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST'://guardar
        break;
        case 'GET':
            if(isset($_GET['id'])){
                Artista::obtenerAlbumes($_GET['id']);
            }else{
                Artista::obtenerArtistas(); 
            }
        break;
        case 'PUT'://actualizar
        break;
        case 'DELETE'://Eliminar
        break;
    }
?>