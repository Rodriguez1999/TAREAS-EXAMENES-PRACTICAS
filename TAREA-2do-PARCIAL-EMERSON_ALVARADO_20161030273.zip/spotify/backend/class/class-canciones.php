<?php
class Canciones{
        private $artista;
        private $album;
        private $cancion;
        private $playlist;

        public function __construct($artista, $album, $cancion, $playlist)
        {
            $this -> artista = $artista;
            $this -> album = $album;
            $this -> cancion = $cancion;
            $this -> playlist = $playlist;
        }

        public function agregarCancion($usuario, $artista, $album, $cancion, $playlist){
            $contenidoArchivoUsuario = file_get_contents("../data/usuarios.json");
            $contenidoArchivoArtista = file_get_contents("../data/artistas.json");
            $usuarios = json_decode($contenidoArchivoUsuario, true);
            $artistas = json_decode($contenidoArchivoArtista, true);

            for($i = 0; $i<sizeof($usuarios); $i++){
                if($usuarios[$i]["codigoUsuario"] == $usuario){
                    for($j = 0; $j<sizeof($artistas); $j++){
                        if($artistas[$j]["codigoArtista"] == $artista){
                            $usuarios[$i]["playlists"][$playlist]["canciones"][] = array(
                            "nombreCancion"=> $artistas[$j]["albumes"][$album]["canciones"][$cancion]["nombreCancion"],
                            "artista"=> $artistas[$j]["nombreArtista"],
                            "album"=> $artistas[$j]["albumes"][$album]["nombreAlbum"]
                            );
                            echo json_encode($usuarios[$i]["playlists"][$playlist]["canciones"]);
                        }
                    }
                break;
                }
            }

            $archivo = fopen("../data/usuarios.json", "w");
            fwrite($archivo, json_encode($usuarios));
            fclose($archivo);

            return 
            ;
        }

        public function getArtista()
        {
                return $this->artista;
        }

        public function setArtista($artista)
        {
                $this->artista = $artista;

                return $this;
        }
 
        public function getAlbum()
        {
                return $this->album;
        }
 
        public function setAlbum($album)
        {
                $this->album = $album;

                return $this;
        }

        public function getCancion()
        {
                return $this->cancion;
        }

        public function setCancion($cancion)
        {
                $this->cancion = $cancion;

                return $this;
        }

        public function getPlaylist()
        {
                return $this->playlist;
        }

        public function setPlaylist($playlist)
        {
                $this->playlist = $playlist;

                return $this;
        }
    }
?>