<?php

    class Usuario{
        private $codigoUsuario;
        private $nombreUsuario;
        private $playlists;

        public function __construct($codigoUsuario, $nombreUsuario, $playlists)
        {
            $this-> codigoUsuario = $codigoUsuario;
            $this-> nombreUsuario = $nombreUsuario;
            $this-> playlists = $playlists;
        }

        public static function obtenerUsuarios()
        {
            $contenidoArchivoUsuario = file_get_contents('../data/usuarios.json');   
            echo $contenidoArchivoUsuario;
            return $contenidoArchivoUsuario;
        
        }

        public static function obtenerPlaylists($index){
            $contenidoArchivoUsuario = file_get_contents('../data/usuarios.json');
            $usuarios = json_decode($contenidoArchivoUsuario, true);
            /*$resultado = array();
            echo json_encode($usuarios[$index]["playlists"][1]);

            for($i = 0; $i < sizeof($usuarios[$index]["playlists"]); $i++){
                    $resultado[] = json_encode($usuarios[$index]["playlists"][$i]);
            }
            
            echo $resultado;*/
            $resultado = array();

            $resultado = $usuarios[$index]["playlists"];
            $resultado = json_encode($resultado);

            echo $resultado;
            return $resultado;
        }

        public function getCodigoUsuario()
        {
                return $this->codigoUsuario;
        }

        public function setCodigoUsuario($codigoUsuario)
        {
                $this->codigoUsuario = $codigoUsuario;

                return $this;
        }

        public function getNombreUsuario()
        {
                return $this->nombreUsuario;
        }

        public function setNombreUsuario($nombreUsuario)
        {
                $this->nombreUsuario = $nombreUsuario;

                return $this;
        }

        public function getPlaylists()
        {
                return $this->playlists;
        }
 
        public function setPlaylists($playlists)
        {
                $this->playlists = $playlists;

                return $this;
        }
    }

?>