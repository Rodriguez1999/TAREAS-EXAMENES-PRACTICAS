<?php

    class Artista{
        private $codigoArtista;
        private $nombreArtista;
        private $albumes;

        public function __construct($codigoArtista, $nombreArtista, $albumes)
        {
            $this -> codigoArtista = $codigoArtista;
            $this -> nombreArtista = $nombreArtista;
            $this -> albumes = $albumes;
        }

        public static function obtenerArtistas(){
            $contenidoArchivoArtistas = file_get_contents('../data/artistas.json');
            echo $contenidoArchivoArtistas;
        }

        public static function obtenerAlbumes($index){
                $contenidoArchivoAlbum = file_get_contents('../data/artistas.json');
                $artistas = json_decode($contenidoArchivoAlbum, true);

                $resultado = array();

                for($i=0; $i < sizeof($artistas); $i++){
                        if($artistas[$i]["codigoArtista"] == $index){
                                $resultado = $artistas[$i]["albumes"];
                                $resultado[] =  $artistas[$i]["nombreArtista"];
                        }
                }
                
                $resultado = json_encode($resultado);
                

                echo $resultado;
                return $resultado;
        }
        

        public function getCodigoArtista()
        {
                return $this->codigoArtista;
        }

        public function setCodigoArtista($codigoArtista)
        {
                $this->codigoArtista = $codigoArtista;

                return $this;
        }

        public function getNombreArtista()
        {
                return $this->nombreArtista;
        }

        public function setNombreArtista($nombreArtista)
        {
                $this->nombreArtista = $nombreArtista;

                return $this;
        }

        public function getAlbumes()
        {
                return $this->albumes;
        }

        public function setAlbumes($albumes)
        {
                $this->albumes = $albumes;

                return $this;
        }
    }
?>