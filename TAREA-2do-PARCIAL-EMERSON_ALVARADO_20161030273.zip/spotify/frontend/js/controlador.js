var numPlaylist;
var artistaG;
var albumG;
var cancionG;
var usuarioActual;

function verPlaylistSeleccionada(codigoPlaylist, usuario){
    ///////////////////////////////// 
    axios({
        method: 'GET',
        url: '../../backend/api/usuarios.php'+`?id=${usuario}`,
        responseType: 'json'
    }).then(res=>{
        playlist = res.data;
        document.getElementById('vista-playlist').innerHTML = ` `;
        
            document.getElementById('vista-playlist').innerHTML += `
                <section class="container-fluid">
                <div class="row">
                <div class="col-4 text-center">
                <h5>${playlist[codigoPlaylist].tituloPlaylist}</h5>
                <div class="cover-image">
                    <i class="fas fa-music fa-9x"></i>
                </div>
                <button class="btn btn-success"type="button">Play</button>
                </div>

                <div class="col-8">
                    ${verCancionesPlay(playlist[codigoPlaylist])}
                </div>
                </div>
                </div>
                </section>
                <hr>
                `;
        
    }).catch(error=>{
        console.error(error);
    })
    ////////////////////////////////

    $("#vista-playlist").show();
    $("#vista-artista").hide();
    
}
function verCancionesPlay(playlist){
    let canciones= ' ';
    for(let j=0; j<playlist.canciones.length; j++){
        canciones +=`
        <div class="row song-item">
            <div class="col-1"><i class="fas fa-play"></i></div>
            <div class="col-10">
            <div class="song-title">${playlist.canciones[j].nombreCancion}</div>
            <div class="song-description">${playlist.canciones[j].artista} - ${playlist.canciones[j].album}</div>
            </div>
            <div class="col-1">
                <span>3:35</span>
            </div>
        </div>
        `;
    }
    return canciones;
}

function verArtista(codigoArtista){
//////////////////////////////
    axios({
        method: 'GET',
        url: '../../backend/api/artistas.php'+`?id=${codigoArtista}`,
        responseType: 'json'
    }).then(res=>{
        album = res.data;
        document.getElementById('vista-artista').innerHTML = ` `;
        
        for(let i=0; i<album.length-1; i++){
            document.getElementById('vista-artista').innerHTML += `
                <section class="container-fluid">
                <div class="row">
                <div class="col-4 text-center">
                    <div class="cover-image" style="background-image:url(${album[i].caratulaAlbum});">
                    </div><br>
                    <h5 class="text-muted">${album[i].nombreAlbum}</h5>
                    <button class="btn btn-success"type="button">Play</button>
                </div>

                <div class="col-8">
                    ${verCanciones(album[i], album[album.length-1], codigoArtista, i)}
                </div>
                </div>
                </div>
                </section>
                <hr>
                `;
             }
        
    }).catch(error=>{
        console.error(error);
    })
/////////////////////////////

    $("#vista-artista").show();
    $("#vista-playlist").hide();
}

function verCanciones(album, artista, codigo, numeroAlbum){
    let canciones= ' ';
    
    for(let j=0; j<album.canciones.length-1; j++){
        canciones +=`
        <div class="row song-item">
            <div class="col-1"><i class="fas fa-play"></i></div>
            <div class="col-10">
            <div class="song-title">${album.canciones[j].nombreCancion}</div>
            <div class="song-description">${artista} - ${album.nombreAlbum}</div>
            </div>
            <div class="col-1">
                <span>${album.canciones[j].duracion}</span>
            
                <button onclick="agregarCancion(${codigo},${numeroAlbum},${j})" class="btn btn-outline-success btn-sm" title="Agregar a playlist"><i class="fas fa-plus"></i></button>
            </div>
        </div>
        `;
        //agregarCancion(${codigo},${numeroAlbum},${j})
    }
    return canciones;
}

function agregarCancion(artista, album, cancion){

    artistaG = artista;
    albumG = album;
    cancionG = cancion;

    $("#modal-playlists").modal('show');
}


function verUsuarios(){
    axios({
        method: 'GET',
        url: '../../backend/api/usuarios.php',
        responseType: 'json'
    }).then(res=>{
        usuarios = res.data;
        document.getElementById('listaUsuarios').innerHTML = ` `;
        document.getElementById('listaUsuarios').innerHTML += `
                        <option value="null">--Seleccione Usuario</option>
                    `;
        for(let i=0; i < usuarios.length; i++){
            document.getElementById('listaUsuarios').innerHTML += `
                        <option value="${i}" onclick= " verPlaylist(${i})">${usuarios[i].nombreUsuario}</option>
                    `;
        }
        
    }).catch(error=>{
        console.error(error);
    })
}

function verArtistas(){
    axios({
        method: 'GET',
        url: '../../backend/api/artistas.php',
        responseType: 'json'
    }).then(res=>{
        artistas = res.data;
        document.getElementById('listaArtistas').innerHTML = ` `;
        for(let i=0; i < artistas.length; i++){
            document.getElementById('listaArtistas').innerHTML += `
            <li class="nav-item"><div class="nav-link" onclick="verArtista(${artistas[i].codigoArtista})"><i class="fas fa-music"></i>${artistas[i].nombreArtista}</div></li>
                    `;
        }
        
    }).catch(error=>{
        console.error(error);
    })
}

function usuarioSeleccionado(){
    let actual = document.getElementById('listaUsuarios').value;
    actual = parseInt(actual);
    usuarioActual= actual + 1;

    document.getElementById('btn-usuario').innerHTML = `<button type="button" class="btn btn-outline-success" data-dismiss="modal" onclick="verPlaylist(${actual})">Seleccionar usuario</button>`;
}

function verPlaylist(indice){
    axios({
        method: 'GET',
        url: '../../backend/api/usuarios.php'+`?id=${indice}`,
        responseType: 'json'
    }).then(res=>{
        playlist = res.data;
        document.getElementById('listaPlaylist').innerHTML = ` `;
        document.getElementById('playlist-cancion').innerHTML = ` `;
        document.getElementById('playlist-cancion').innerHTML += `
                        <option value="null">--Seleccione Playlist</option>
                    `;
        for(let i=0; i < playlist.length; i++){
            document.getElementById('listaPlaylist').innerHTML += `
                <li class="nav-item"><div class="nav-link" onclick="verPlaylistSeleccionada(${i}, ${indice})"><i class="fas fa-play"></i>${playlist[i].tituloPlaylist}</div></li>
                    `;
            document.getElementById('playlist-cancion').innerHTML += `<option value="${i}">${playlist[i].tituloPlaylist}</option> `;
                    
        }
    }).catch(error=>{
        console.error(error);
    })
}

function playlistSeleccionada(){
    let actual = document.getElementById('playlist-cancion').value;
    numPlaylist = actual;

    document.getElementById('btn-playlist').innerHTML = `<button type="button" class="btn btn-outline-success" data-dismiss="modal" onclick="guardarPlaylist()">Seleccionar Playlist</button>`;
}

function guardarPlaylist(){
    let datosCancion = {
        usuario: usuarioActual,
        artista: artistaG,
        album: albumG,
        cancion: cancionG,
        playlist: numPlaylist
    }
    axios({
        method: 'PUT',
        url: '../../backend/api/canciones.php'+`?id=${artistaG}`,
        responseType: 'json',
        data: datosCancion
    }).then(res=>{
    }).catch(error=>{
        console.error(error);
    })
}