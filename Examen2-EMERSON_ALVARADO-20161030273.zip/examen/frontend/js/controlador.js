// Generando listas de categorias para pintarlas en pantalla ya estilizadas
function pintandoCategoriasLugo () {
    axios({
        method: 'GET',
        url: '../backend/api/categoria.php',
        responseType: 'json'
    }).then(res=>{
        categ = res.data;
        document.getElementById('contenedor-categorias').innerHTML = ``;
        for(let i=0;i<categ.length;i++) {
            document.getElementById('contenedor-categorias').innerHTML += `
            <div class="col-lg-3 col-md-4 col-sm-6 mt-2">
                <div class="card-item card" style="background: ${categ[i].color};" onclick="infoCategorias(${categ[i].idCategoria})">
                    <div class="row">
                        <div class="col mx-auto text-center m-3">
                            <i class="${categ[i].icono} cat-icon"></i>
                        </div>
                        <div class="col">

                        </div>
                    </div>
                    <div class="row m-3 mt-4">
                        <section class="col">
                            <h3 class="text-white font-weight-bolder">${categ[i].nombreCategoria}</h3>
                            <p class="text-white" style="font-size: 13px;">
                                ${categ[i].empresas.length} Comercios
                            </p>
                        </section>
                    </div>
                </div>
            </div>
            `;
        }
            
    }).catch(error=>{
        console.error(error);
    });
}

// Generando Usuarios 
function listaUsuarios() { 
    axios({
        method: 'GET',
        url: '../backend/api/usuario.php',
        responseType: 'json'
    }).then(res=>{
        user = res.data;
        document.getElementById('usuarioActual').innerHTML = '';
        for (let i=0;i < user.length ; i++) {
            document.getElementById('usuarioActual').innerHTML += 
            `<option value="${ user[i].idUsuario }">${ user[i].nombre } ${ user[i].apellido }</option>`;
        }
        cambiarUsuario();
            
    }).catch(error=>{
        console.error(error);
    });
}


// Onchange para seleccionar un usuario
function cambiarUsuario () {
    let usuarioSeleccionado = document.getElementById('usuarioActual').value;
    axios({
        method: 'GET',
        url: '../backend/api/usuario.php'+`?id=${usuarioSeleccionado}`,
        responseType: 'json'
    }).then(res=>{
        user = res.data;
        document.getElementById('texto-hola').innerHTML = `¡Hola ${user.nombre}!`;
    }).catch(error=>{
        console.error(error);
    });
    return usuarioSeleccionado; 
}

// Ver Ordenes de un usuario con el boton de ver ordenes
function verOrdenes() {
    let usuario = cambiarUsuario();
    axios({
        method: 'GET',
        url: '../backend/api/usuario.php'+`?id=${usuario}`,
        responseType: 'json'
    }).then(res=>{
        user = res.data;
        // Header Modal
        document.querySelector('#modalUserLabel').innerHTML = `${user.nombre} , Estas Son Tus Ordenes.`;
        // Zona de Productos
        document.querySelector('#zona-productos').innerHTML = '';
        for(let i=0;i<user.ordenes.length;i++) {
            document.querySelector('#zona-productos').innerHTML += `
                <p>
                    <h3 style="color: #563D7C; font-weight: bold;">${ user.ordenes[i].nombreProducto }</h3>
                </p>
                <p style="font-size: 18px;">
                    ${user.ordenes[i].descripcion}
                </p>
                <p class="ml-auto">
                    <b style="font-size: 25px">$${user.ordenes[i].precio}</b>
                </p>
                <hr>
            `;
        }
        
    }).catch(error=>{
        console.error(error);
    });
}

// Ver info sobre categorias
function infoCategorias(idCategoria) {
    axios({
        method: 'GET',
        url: '../backend/api/categoria.php'+`?id=${idCategoria}`,
        responseType: 'json'
    }).then(res=>{
        categoria = res.data;
        document.getElementById('zona-categorias').innerHTML = ``;
        $('#modalCategorias').modal('show');
            document.getElementById('header-categorias').innerHTML = `<i class="${categoria.icono}"></i> ${ categoria.nombreCategoria }`;
            document.getElementById('head-color').style.backgroundColor = `${categoria.color}`; 

            let total = "";
            for(let i=0; i<categoria.empresas.length; i++){
                total = ' ';
                for(let j=0; j < categoria.empresas[i].productos.length; j++) {
                    total += `
                        <div class="row p-2">
                            <div class="col-lg-7">
                                <h4 style="color:#563D7C;">${ categoria.empresas[i].productos[j].nombreProducto }</h4>
                            </div>
                            <div class="col-lg-5">
                                <input type="button" class="btn btn-secondary" onclick="pedir(${ categoria.idCategoria } , ${ categoria.empresas[i].idEmpresa } ,${categoria.empresas[i].productos[j].idProducto})" value="Pedir">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-8">
                                <p>${ categoria.empresas[i].productos[j].descripcion }</p>
                            </div>
                            <div class="col-lg-4 ml-auto">
                                <b>$ ${ categoria.empresas[i].productos[j].precio }</b>
                            </div>
                        </div>  
                    `;
                }

                document.getElementById('zona-categorias').innerHTML += `
                    <div class="col-lg-6 col-sm-12 mt-2">
                        <div class="card" style="border-radius:12px">
                            <section>
                                <img src="${categoria.empresas[i].imagen}" class="img-fluid" style="border-radius: 12px"/>
                                <h3 style="color: #fff; font-weight:bolder;">${ categoria.empresas[i].nombreEmpresa }</h3>
                            </section>
                            <section class="p-3">
                                ${ total }
                            </section>
                        </div>
                    </div>
                `;
            }  
    }).catch(error=>{
        console.error(error);
    });

};

// Funcion para pedir orden a los usuarios
function pedir (idCategoria , idEmpresa , idProducto) {
    $('#modalPedidos').modal('show');
    axios({
        method: 'PUT',
        url: '../backend/api/categoria.php',
        responseType: 'json',
        data:{
            categoria: idCategoria,
            empresa: idEmpresa,
            producto: idProducto
        }
    }).then(res=>{
        producto = res.data;
        document.getElementById('zona-pedidos').innerHTML =`
            <h3>${ producto.nombreProducto }</h3><br>
            <p>${ producto.descripcion }</p><br>
            <div class="row">
                <div class="col-lg-4">
                    Cantidad A Solicitar : 
                </div>
                <div class="col-lg-8">
                    <input type="text" class="form-control" id="cantidad" />    
                </div>
            </div>
            <div class="row">
                <div class="col-lg-10 mr-auto">
                    
                </div>
                <div class="col-lg-2"><br>
                <b>$ ${producto.precio}</b>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" onclick="agregarPedido('${producto.nombreProducto}','${producto.descripcion}',${producto.precio})" 
                class="btn btn-secondary">
                Procesar Orden</button>
            </div>
        `;
    }).catch(error=>{
        console.error(error);
    });

}

// Funcion para agregar un producto nuevo a un usuario 
function agregarPedido(nombreProduct, description, valor) {
    let cantidad = document.getElementById('cantidad').value;
    let orden =
        {
            nombreProducto:nombreProduct,
            descripcion: description,
            cantidad: cantidad,
            precio: valor,
            usuario: document.getElementById('usuarioActual').value
        };
    axios({
        method: 'POST',
        url: '../backend/api/usuario.php',
        responseType: 'json',
        data: orden
    }).then(res=>{
        respuesta = res.data;
            
    }).catch(error=>{
        console.error(error);
    });
    pintandoCategoriasLugo();
    $('#modalPedidos').modal('hide');
    $('#modalCategorias').modal('hide');
}

// creando una nueva categoria
function crearCategoria() {
    $('#modalPedidos').modal('hide');
    $('#modalCategorias').modal('hide');
    $('#modalCreacionCategoria').modal('show');

}

function guardar() {
    let txtnombre = document.getElementById('txt-nombre').value;
    let txtdescripcion = document.getElementById('txt-descripcion').value;
    let txtcolor = document.getElementById('txt-color').value;
    let txticono = document.getElementById('txt-icono').value;
    let categoria = 
    {
        nombreCategoria:txtnombre,
        descripcion:txtdescripcion,
        color:txtcolor,
        icono:txticono
    };

    axios({
        method: 'POST',
        url: '../backend/api/categoria.php',
        responseType: 'json',
        data: categoria
    }).then(res=>{
        document.getElementById('txt-nombre').value= null;
        document.getElementById('txt-descripcion').value= null;
        document.getElementById('txt-color').value= null;
        document.getElementById('txt-icono').value= null;
        pintandoCategoriasLugo();

    }).catch(error=>{
        console.error(error);
    });

    $('#modalPedidos').modal('hide');
    $('#modalCategorias').modal('hide');
    $('#modalCreacionCategoria').modal('show');
}