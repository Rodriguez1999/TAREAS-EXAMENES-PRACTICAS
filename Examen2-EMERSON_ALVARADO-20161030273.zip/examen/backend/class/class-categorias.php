<?php

    class Categorias{
        private $idCategaria;
        private $nombreCategoria;
        private $descripcion;
        private $color;
        private $icono;

        public function __construct(
            $nombreCategoria,
            $descripcion,
            $color,
            $icono
        )
        {
            $this -> nombreCategoria = $nombreCategoria;
            $this -> descripcion = $descripcion;
            $this -> color = $color;
            $this -> icono = $icono;   
        }

        public static function obtenerCategoria($index){
            $contenidoArchivo = file_get_contents('../data/categorias.json');
            $categoria = json_decode($contenidoArchivo, true);

            $contenidoArchivoEmpresas = file_get_contents('../data/empresas.json');
            $empresas = json_decode($contenidoArchivoEmpresas, true);

            $cate = array();
            $emp = array();
            $productos = array();

            for($i=0; $i<sizeof($categoria); $i++){
                if($index == $categoria[$i]["idCategoria"]){
                    for($j=0; $j<sizeof($categoria[$i]["empresas"]); $j++){
                        for($k=0; $k<sizeof($empresas); $k++){
                            if($categoria[$i]["empresas"][$j] == $empresas[$k]["idEmpresa"]){
                                for($l=0; $l<sizeof($empresas[$k]["productos"]); $l++){
                                    $productos[]=array(
                                        "idProducto"=> $empresas[$k]["productos"][$l]["idProducto"],
                                        "nombreProducto"=> $empresas[$k]["productos"][$l]["nombreProducto"],
                                        "descripcion"=> $empresas[$k]["productos"][$l]["descripcion"],
                                        "precio"=> $empresas[$k]["productos"][$l]["precio"]
                                    );
                                }
                                $emp[] =array(
                                    "nombreEmpresa" => $empresas[$k]["nombreEmpresa"],
                                    "imagen" => $empresas[$k]["imagen"],
                                    "idEmpresa" =>$empresas[$k]["idEmpresa"],
                                    "productos" => $productos

                                );
                                $productos = array();
                            }
                        }
                    }
                    $cate=array(
                        "idCategoria"=>$categoria[$i]["idCategoria"],
                        "nombreCategoria"=> $categoria[$i]["nombreCategoria"],
                        "descripcion"=>$categoria[$i]["descripcion"],
                        "color"=>$categoria[$i]["color"],
                        "icono"=>$categoria[$i]["icono"],
                        "empresas" => $emp
                    );
                }
            }

            return json_encode($cate);
        }

        public static function obtenerProducto($categoria, $empresa, $producto){
            $contenidoArchivo = file_get_contents('../data/categorias.json');
            $categorias = json_decode($contenidoArchivo, true);

            $contenidoArchivo = file_get_contents('../data/empresas.json');
            $empresas = json_decode($contenidoArchivo, true);

            for($i=0; $i<sizeof($empresas); $i++){
                if($empresa == $empresas[$i]["idEmpresa"]){
                    for($j=0; $j < sizeof($empresas[$i]["productos"]); $j++){
                        if($producto == $empresas[$i]["productos"][$j]["idProducto"]){
                            $producto = array(
                                "idProducto"=> $empresas[$i]["productos"][$j]["idProducto"],
                                "nombreProducto"=> $empresas[$i]["productos"][$j]["nombreProducto"],
                                "descripcion"=> $empresas[$i]["productos"][$j]["descripcion"],
                                "precio"=> $empresas[$i]["productos"][$j]["precio"]
                            );
                            return json_encode($producto);
                        }
                    }
                }

            }

        }

        public static function obtenerCategorias(){
            $contenidoArchivo = file_get_contents('../data/categorias.json');
            $categorias = json_decode($contenidoArchivo, true);

            return json_encode($categorias);

        }

        public function guardarCategoria(){
            $contenidoArchivo = file_get_contents('../data/categorias.json');
            $categoria = json_decode($contenidoArchivo, true);

            $this->idCategoria = $categoria[sizeof($categoria)-1]["idCategoria"] + 1;

            $categoria[]= array(
                "idCategoria"=> $this-> idCategoria,
                "nombreCategoria"=> $this-> nombreCategoria,
                "descripcion"=>$this-> descripcion,
                "color"=>$this-> color,
                "icono"=>$this-> icono,
                "empresas"=> []
            );

            $archivo = fopen("../data/categorias.json", "w");
            fwrite($archivo, json_encode($categoria));
            fclose($archivo);

            return '{"valor": true, "mensaje":"Categoria Registrada con exito."}';
        }
        

        public function getNombreCategoria()
        {
                return $this->nombreCategoria;
        }

        public function setNombreCategoria($nombreCategoria)
        {
                $this->nombreCategoria = $nombreCategoria;

                return $this;
        }

        public function getDescripcion()
        {
                return $this->descripcion;
        }

        public function setDescripcion($descripcion)
        {
                $this->descripcion = $descripcion;

                return $this;
        }

        public function getColor()
        {
                return $this->color;
        }

        public function setColor($color)
        {
                $this->color = $color;

                return $this;
        }

        public function getIcono()
        {
                return $this->icono;
        }

        public function setIcono($icono)
        {
                $this->icono = $icono;

                return $this;
        }

        public function getIdCategaria()
        {
                return $this->idCategaria;
        }

        public function setIdCategaria($idCategaria)
        {
                $this->idCategaria = $idCategaria;

                return $this;
        }
    }

?>