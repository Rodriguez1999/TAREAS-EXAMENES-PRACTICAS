<?php

    class Usuario{
        private $nombreProducto;
        private $descripcion;
        private $cantidad;
        private $precio;


        public function __construct(
            $nombreProducto,
            $descripcion,
            $cantidad,
            $precio
        )
        {
            $this->nombreProducto = $nombreProducto;
            $this->descripcion = $descripcion;
            $this->cantidad = $cantidad;   
            $this->precio = $precio;              
        }

        public static function obtenerUsuario($id){
            $contenidoArchivoEmpresas = file_get_contents('../data/usuarios.json');
            $usuarios = json_decode($contenidoArchivoEmpresas, true);

            for($i=0; $i<sizeof($usuarios); $i++)
            {
                if($id == $usuarios[$i]["idUsuario"])
                {
                    return json_encode($usuarios[$i]);
                }
            }

        }

        public static function obtenerUsuarios(){
            $contenidoArchivoEmpresas = file_get_contents('../data/usuarios.json');
            $usuarios = json_decode($contenidoArchivoEmpresas, true);

            return json_encode($usuarios);
        }
        
        public function guardarOrden($index){
            $contenidoArchivoEmpresas = file_get_contents('../data/usuarios.json');
            $usuarios = json_decode($contenidoArchivoEmpresas, true);

            for($i=0; $i<sizeof($usuarios); $i++){
                if($index == $usuarios[$i]["idUsuario"])
                {
                    $usuarios[$i]["ordenes"][] = array(
                        "nombreProducto"=> $this->nombreProducto,
                        "descripcion"=> $this->descripcion,
                        "cantidad"=> $this->cantidad,
                        "precio"=>  $this->precio
                    );
                    $archivo = fopen("../data/usuarios.json", "w");
                    fwrite($archivo, json_encode($usuarios));
                    fclose($archivo);
                    return '{"valor": true, "mensaje":"Orden guardada con exito."}';
        
                    
                }

            }  
            return '{"valor": false, "mensaje":"Error al registrar orden."}';
            
        }

        public function getNombreProducto()
        {
                return $this->nombreProducto;
        }

        public function setNombreProducto($nombreProducto)
        {
                $this->nombreProducto = $nombreProducto;

                return $this;
        }

        public function getDescripcion()
        {
                return $this->descripcion;
        }

        public function setDescripcion($descripcion)
        {
                $this->descripcion = $descripcion;

                return $this;
        }

        public function getCantidad()
        {
                return $this->cantidad;
        }
 
        public function setCantidad($cantidad)
        {
                $this->cantidad = $cantidad;

                return $this;
        }

        public function getPrecio()
        {
                return $this->precio;
        }

        public function setPrecio($precio)
        {
                $this->precio = $precio;

                return $this;
        }
        }



?>