<?php
    header("Content-type: application/json");
    include_once("../class/class-usuarios.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST'://guardar
            $_POST =json_decode(file_get_contents('php://input'), true); 
            $orden = new Usuario($_POST["nombreProducto"],
                                $_POST["descripcion"],
                                $_POST["cantidad"],
                                $_POST["precio"]);
        
            echo $orden -> guardarOrden($_POST["usuario"]);
            
        break;
        case 'GET':
            if(isset($_GET['id'])){
                echo json_encode(Usuario::obtenerUsuario($_GET['id']));
            }else{
                echo Usuario::obtenerUsuarios(); 
            }
        break;
        case 'PUT'://actualizar
            $_PUT =json_decode(file_get_contents('php://input'), true); 
        break;
        case 'DELETE'://Eliminar
        break;
    }
?>