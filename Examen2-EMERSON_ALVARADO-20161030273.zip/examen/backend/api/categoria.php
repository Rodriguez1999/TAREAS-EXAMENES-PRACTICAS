<?php
    header("Content-type: application/json");
    include_once("../class/class-categorias.php");
    switch($_SERVER['REQUEST_METHOD']){
        case 'POST'://guardar
            $_POST =json_decode(file_get_contents('php://input'), true); 
            $categoria = new Categorias($_POST["nombreCategoria"],
                                        $_POST["descripcion"],
                                        $_POST["color"],
                                        $_POST["icono"]);
        
            echo $categoria -> guardarCategoria();
            
        break;
        case 'GET':
            if(isset($_GET['id'])){
                echo Categorias::obtenerCategoria($_GET["id"]);
            }else{
                echo Categorias::obtenerCategorias(); 
            }
        break;
        case 'PUT'://actualizar
            $_PUT =json_decode(file_get_contents('php://input'), true);
            echo Categorias::obtenerProducto($_PUT["categoria"], $_PUT["empresa"], $_PUT["producto"]);
            
        break;
        case 'DELETE'://Eliminar
        break;
    }
?>